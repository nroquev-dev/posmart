'use client';
import React from 'react';
import { X, Minus, Plus, Trash2, ShoppingBag, ShoppingCart } from 'lucide-react';
import AppImage from '@/components/ui/AppImage';
import { useCartStore } from '@/store/cartStore';
import { toast } from 'sonner';

export default function CartDrawer() {
  const {
    items,
    isOpen,
    closeCart,
    removeItem,
    updateQuantity,
    clearCart,
    getTotal,
    getTax,
    getGrandTotal,
  } = useCartStore();

  const handleRemove = (id: string, name: string) => {
    removeItem(id);
    toast.success(`"${name}" eliminado del carrito`);
  };

  const handleClear = () => {
    clearCart();
    toast.info('Carrito vaciado');
  };

  const handleCheckout = () => {
    toast.success(`¡Pedido realizado! Total: $${getGrandTotal().toFixed(2)}`, {
      description: `${items.reduce((s, i) => s + i.quantity, 0)} artículos procesados`,
    });
    clearCart();
    closeCart();
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div
        className="drawer-overlay-enter fixed inset-0 z-50 bg-foreground/30 backdrop-blur-sm"
        onClick={closeCart}
        aria-hidden="true"
      />

      {/* Drawer */}
      <aside className="drawer-enter fixed right-0 top-0 bottom-0 z-50 w-full max-w-md bg-card shadow-drawer flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div className="flex items-center gap-2">
            <ShoppingCart size={20} className="text-primary" />
            <h2 className="text-lg font-semibold text-foreground">Pedido Actual</h2>
            {items.length > 0 && (
              <span className="ml-1 px-2 py-0.5 bg-primary/10 text-primary text-xs font-semibold rounded-full">
                {items.reduce((s, i) => s + i.quantity, 0)} artículos
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {items.length > 0 && (
              <button
                onClick={handleClear}
                className="text-xs text-muted-foreground hover:text-negative transition-colors px-2 py-1 rounded hover:bg-red-50"
              >
                Vaciar todo
              </button>
            )}
            <button
              onClick={closeCart}
              className="p-1.5 rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
              aria-label="Cerrar carrito"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full gap-4 py-16">
              <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center">
                <ShoppingBag size={28} className="text-muted-foreground" />
              </div>
              <div className="text-center">
                <p className="font-semibold text-foreground">No hay artículos en el carrito</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Agrega productos del catálogo para iniciar un pedido
                </p>
              </div>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={`cart-item-${item.product.id}`}
                className="flex gap-3 p-3 bg-background rounded-xl border border-border hover:border-primary/20 transition-colors"
              >
                <div className="w-14 h-14 rounded-lg overflow-hidden shrink-0 bg-muted">
                  <AppImage
                    src={item.product.image}
                    alt={item.product.name}
                    width={56}
                    height={56}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground leading-tight line-clamp-2">
                    {item.product.name}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">{item.product.sku}</p>
                  <div className="flex items-center justify-between mt-2">
                    {/* Qty controls */}
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                        className="w-7 h-7 flex items-center justify-center rounded-md border border-border text-muted-foreground hover:bg-muted hover:text-foreground transition-colors active:scale-95"
                        aria-label={`Disminuir cantidad de ${item.product.name}`}
                      >
                        <Minus size={12} />
                      </button>
                      <span className="w-8 text-center text-sm font-semibold tabular-nums">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        className="w-7 h-7 flex items-center justify-center rounded-md border border-border text-muted-foreground hover:bg-muted hover:text-foreground transition-colors active:scale-95"
                        aria-label={`Aumentar cantidad de ${item.product.name}`}
                      >
                        <Plus size={12} />
                      </button>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-foreground tabular-nums">
                        ${(item.product.price * item.quantity).toFixed(2)}
                      </span>
                      <button
                        onClick={() => handleRemove(item.product.id, item.product.name)}
                        className="p-1 rounded text-muted-foreground hover:text-negative hover:bg-red-50 transition-colors"
                        aria-label={`Eliminar ${item.product.name} del carrito`}
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer totals */}
        {items.length > 0 && (
          <div className="border-t border-border px-5 py-4 space-y-3 bg-card">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-medium tabular-nums">${getTotal().toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Impuesto (8.75%)</span>
                <span className="font-medium tabular-nums">${getTax().toFixed(2)}</span>
              </div>
              <div className="h-px bg-border" />
              <div className="flex justify-between">
                <span className="font-semibold text-foreground">Total</span>
                <span className="text-xl font-bold text-primary tabular-nums">
                  ${getGrandTotal().toFixed(2)}
                </span>
              </div>
            </div>
            <button
              onClick={handleCheckout}
              className="w-full py-3 bg-primary text-primary-foreground font-semibold rounded-xl text-sm hover:bg-primary/90 active:scale-95 transition-all duration-150"
            >
              Completar Venta — ${getGrandTotal().toFixed(2)}
            </button>
          </div>
        )}
      </aside>
    </>
  );
}