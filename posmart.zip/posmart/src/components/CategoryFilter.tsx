'use client';
import React, { useRef } from 'react';
import { CATEGORIES } from '@/data/products';
import { ChevronLeft, ChevronRight } from 'lucide-react';

type Props = {
  selected: string;
  onChange: (cat: string) => void;
  counts: Record<string, number>;
};

export default function CategoryFilter({ selected, onChange, counts }: Props) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: 'left' | 'right') => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: dir === 'left' ? -160 : 160, behavior: 'smooth' });
    }
  };

  return (
    <div className="relative flex items-center gap-1">
      <button
        onClick={() => scroll('left')}
        className="hidden sm:flex shrink-0 w-8 h-8 items-center justify-center rounded-lg border border-border bg-card text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
        aria-label="Desplazar categorías a la izquierda"
      >
        <ChevronLeft size={16} />
      </button>

      <div
        ref={scrollRef}
        className="flex items-center gap-2 overflow-x-auto scrollbar-hide scroll-smooth flex-1 py-1"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {CATEGORIES.map((cat) => {
          const count = counts[cat] ?? 0;
          const active = selected === cat;
          return (
            <button
              key={`cat-filter-${cat}`}
              onClick={() => onChange(cat)}
              className={`shrink-0 flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-medium transition-all duration-150 whitespace-nowrap border ${
                active
                  ? 'bg-primary text-primary-foreground border-primary shadow-sm'
                  : 'bg-card text-muted-foreground border-border hover:bg-muted hover:text-foreground hover:border-border'
              }`}
            >
              {cat}
              {cat !== 'Todos' && (
                <span
                  className={`text-xs px-1.5 py-0.5 rounded-full tabular-nums ${
                    active ? 'bg-primary-foreground/20 text-primary-foreground' : 'bg-muted text-muted-foreground'
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      <button
        onClick={() => scroll('right')}
        className="hidden sm:flex shrink-0 w-8 h-8 items-center justify-center rounded-lg border border-border bg-card text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
        aria-label="Desplazar categorías a la derecha"
      >
        <ChevronRight size={16} />
      </button>
    </div>
  );
}