'use client';
import React, { useState } from 'react';
import Link from 'next/link';
import { ShoppingCart, Plus, AlertTriangle } from 'lucide-react';
import AppImage from '@/components/ui/AppImage';
import { useCartStore } from '@/store/cartStore';
import { toast } from 'sonner';
import type { Product } from '@/data/products';

type Props = {
  product: Product;
};

const CATEGORY_COLORS: Record<string, string> = {
  Bebidas: 'bg-blue-50 text-blue-700',
  Snacks: 'bg-orange-50 text-orange-700',
  Lácteos: 'bg-yellow-50 text-yellow-700',
  Panadería: 'bg-amber-50 text-amber-700',
  'Frutas y Verduras': 'bg-green-50 text-green-700',
  Congelados: 'bg-cyan-50 text-cyan-700',
  'Cuidado Personal': 'bg-purple-50 text-purple-700',
  Hogar: 'bg-slate-100 text-slate-700',
};

export default function ProductCard({ product }: Props) {
  const { addItem, openCart } = useCartStore();
  const [adding, setAdding] = useState(false);
  const isLowStock = product.stock <= 10;
  const isOutOfStock = product.stock === 0;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    if (isOutOfStock) return;
    setAdding(true);
    addItem(product);
    toast.success(`Agregado al carrito`, {
      description: product.name,
      action: { label: 'Ver Carrito', onClick: openCart },
    });
    setTimeout(() => setAdding(false), 350);
  };

  const badgeColor = CATEGORY_COLORS[product.category] ?? 'bg-muted text-muted-foreground';

  return (
    <Link
      href={`/product-detail?id=${product.id}`}
      className="group relative bg-card rounded-xl border border-border card-hover flex flex-col overflow-hidden focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      {/* Imagen */}
      <div className="relative aspect-square overflow-hidden bg-muted">
        <AppImage
          src={product.image}
          alt={`Imagen del producto ${product.name}`}
          fill
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
          className="object-cover transition-transform duration-300 group-hover:scale-105"
        />
        {isLowStock && !isOutOfStock && (
          <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-1 bg-warning/90 text-white text-xs font-semibold rounded-full backdrop-blur-sm">
            <AlertTriangle size={10} />
            Poco Stock
          </div>
        )}
        {isOutOfStock && (
          <div className="absolute inset-0 bg-foreground/40 flex items-center justify-center">
            <span className="px-3 py-1 bg-card text-foreground text-sm font-semibold rounded-full">
              Sin Stock
            </span>
          </div>
        )}
      </div>

      {/* Contenido */}
      <div className="flex flex-col flex-1 p-3 gap-2">
        <div className="flex items-start justify-between gap-2">
          <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${badgeColor}`}>
            {product.category}
          </span>
          <span className="text-xs text-muted-foreground tabular-nums">{product.unit}</span>
        </div>
        <p className="text-sm font-semibold text-foreground leading-snug line-clamp-2 min-h-[2.5rem]">
          {product.name}
        </p>
        <div className="flex items-center justify-between mt-auto pt-1">
          <span className="text-lg font-bold text-foreground tabular-nums">
            ${product.price.toFixed(2)}
          </span>
          <button
            onClick={handleAddToCart}
            disabled={isOutOfStock}
            className={`add-to-cart-pulse flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all duration-150 active:scale-95 ${
              isOutOfStock
                ? 'bg-muted text-muted-foreground cursor-not-allowed'
                : adding
                ? 'bg-positive text-white' :'bg-primary text-primary-foreground hover:bg-primary/90'
            }`}
            aria-label={`Agregar ${product.name} al carrito`}
          >
            {adding ? (
              <>
                <Plus size={13} />
                ¡Agregado!
              </>
            ) : (
              <>
                <ShoppingCart size={13} />
                Agregar
              </>
            )}
          </button>
        </div>
      </div>
    </Link>
  );
}