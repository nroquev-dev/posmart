'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  ShoppingCart,
  LayoutDashboard,
  Store,
  Menu,
  X,
  ChevronDown,
} from 'lucide-react';
import AppLogo from '@/components/ui/AppLogo';
import { useCartStore } from '@/store/cartStore';
import Icon from '@/components/ui/AppIcon';


const NAV_LINKS = [
  { href: '/', label: 'Catálogo de Productos', icon: Store },
  { href: '/admin-dashboard', label: 'Panel de Administración', icon: LayoutDashboard },
];

export default function Navbar() {
  const pathname = usePathname();
  const { getItemCount, toggleCart } = useCartStore();
  const [mounted, setMounted] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const itemCount = mounted ? getItemCount() : 0;

  return (
    <>
      <header className="sticky top-0 z-40 bg-card border-b border-border shadow-card">
        <div className="max-w-screen-2xl mx-auto px-4 lg:px-8 xl:px-10 h-16 flex items-center justify-between gap-4">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <AppLogo size={36} />
            <span className="font-semibold text-lg text-foreground tracking-tight hidden sm:block">
              POSmart
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {NAV_LINKS?.map((link) => {
              const Icon = link?.icon;
              const active = pathname === link?.href || (link?.href !== '/' && pathname?.startsWith(link?.href));
              return (
                <Link
                  key={`nav-${link?.href}`}
                  href={link?.href}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150 ${
                    active
                      ? 'bg-primary/10 text-primary' :'text-muted-foreground hover:bg-muted hover:text-foreground'
                  }`}
                >
                  <Icon size={16} />
                  {link?.label}
                </Link>
              );
            })}
          </nav>

          {/* Right actions */}
          <div className="flex items-center gap-2">
            {/* Role badge */}
            <div className="hidden sm:flex items-center gap-1 px-3 py-1.5 bg-muted rounded-lg">
              <ChevronDown size={12} className="text-muted-foreground" />
              <span className="text-xs font-medium text-muted-foreground">Cajero</span>
            </div>

            {/* Cart button */}
            <button
              onClick={toggleCart}
              className="relative flex items-center gap-2 px-3 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium transition-all duration-150 hover:bg-primary/90 active:scale-95"
              aria-label={`Abrir carrito, ${itemCount} artículos`}
            >
              <ShoppingCart size={18} />
              <span className="hidden sm:inline">Carrito</span>
              {itemCount > 0 && (
                <span className="cart-badge-bounce absolute -top-1.5 -right-1.5 min-w-[20px] h-5 bg-accent text-accent-foreground text-xs font-bold rounded-full flex items-center justify-center px-1 tabular-nums">
                  {itemCount > 99 ? '99+' : itemCount}
                </span>
              )}
            </button>

            {/* Mobile menu */}
            <button
              className="md:hidden p-2 rounded-lg text-muted-foreground hover:bg-muted transition-colors"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Alternar menú de navegación"
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile Nav Drawer */}
        {mobileOpen && (
          <div className="md:hidden border-t border-border bg-card px-4 py-3 flex flex-col gap-1">
            {NAV_LINKS?.map((link) => {
              const Icon = link?.icon;
              const active = pathname === link?.href;
              return (
                <Link
                  key={`mobile-nav-${link?.href}`}
                  href={link?.href}
                  onClick={() => setMobileOpen(false)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                    active
                      ? 'bg-primary/10 text-primary' :'text-muted-foreground hover:bg-muted hover:text-foreground'
                  }`}
                >
                  <Icon size={18} />
                  {link?.label}
                </Link>
              );
            })}
          </div>
        )}
      </header>
    </>
  );
}