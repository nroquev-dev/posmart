export type Product = {
  id: string;
  name: string;
  price: number;
  category: string;
  image: string;
  description: string;
  stock: number;
  sku: string;
  unit: string;
};

export const CATEGORIES = [
'Todos',
'Bebidas',
'Snacks',
'Lácteos',
'Panadería',
'Frutas y Verduras',
'Congelados',
'Cuidado Personal',
'Hogar'];


export const PRODUCTS: Product[] = [
{
  id: 'prod-001',
  name: 'Agua Mineral con Gas 500ml',
  price: 1.99,
  category: 'Bebidas',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_164f03967-1779138588783.png",
  description: 'Agua mineral naturalmente carbonatada proveniente de manantiales alpinos. Cero calorías, sin aditivos. Perfecta para mantenerse hidratado durante el día.',
  stock: 142,
  sku: 'BEV-SMW-500',
  unit: 'botella'
},
{
  id: 'prod-002',
  name: 'Cold Brew Café 355ml',
  price: 4.49,
  category: 'Bebidas',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_16722d0b8-1777061832777.png",
  description: 'Café cold brew suave y de baja acidez, macerado durante 20 horas. Ligeramente endulzado con azúcar de caña. Notas de espresso intenso con un final limpio.',
  stock: 58,
  sku: 'BEV-CBC-355',
  unit: 'lata'
},
{
  id: 'prod-003',
  name: 'Jugo de Naranja Premium 1L',
  price: 5.29,
  category: 'Bebidas',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1611d91ba-1779068565718.png",
  description: 'Jugo de naranja premium recién exprimido sin azúcares añadidos ni conservantes. 100% naranjas puras de Florida. Refrigerar después de abrir.',
  stock: 34,
  sku: 'BEV-OJP-1L',
  unit: 'cartón'
},
{
  id: 'prod-004',
  name: 'Papas Fritas con Sal Marina 180g',
  price: 3.79,
  category: 'Snacks',
  image: "https://images.unsplash.com/photo-1733907502035-9631c6410c44",
  description: 'Papas fritas artesanales de corte grueso sazonadas con sal marina gruesa. Crujiente satisfactorio con un sabor clásico y limpio. Certificado sin OGM.',
  stock: 87,
  sku: 'SNK-SSK-180',
  unit: 'bolsa'
},
{
  id: 'prod-005',
  name: 'Barra de Chocolate Negro 85% 100g',
  price: 4.99,
  category: 'Snacks',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1fbfc8a24-1772275598737.png",
  description: 'Chocolate negro intenso al 85% de cacao de origen único ecuatoriano. Sabor rico y complejo con notas terrosas. Vegano.',
  stock: 63,
  sku: 'SNK-DCB-100',
  unit: 'barra'
},
{
  id: 'prod-006',
  name: 'Barras de Granola Surtidas 6 unidades',
  price: 6.49,
  category: 'Snacks',
  image: "https://images.unsplash.com/photo-1633360821154-1935fb5671e6",
  description: 'Barras de granola a base de avena en tres sabores: almendra con miel, arándano y chispas de chocolate. 5g de proteína por barra. Sin sabores artificiales.',
  stock: 41,
  sku: 'SNK-GBM-6CT',
  unit: 'paquete'
},
{
  id: 'prod-007',
  name: 'Leche Entera 1 Galón',
  price: 4.29,
  category: 'Lácteos',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1be3caa70-1768121442413.png",
  description: 'Leche entera fresca de vacas locales alimentadas con pasto. Enriquecida con vitamina D. Pasteurizada y homogeneizada. Fecha de vencimiento impresa en la tapa.',
  stock: 22,
  sku: 'DAI-WMG-1GL',
  unit: 'galón'
},
{
  id: 'prod-008',
  name: 'Yogur Griego Natural 32oz',
  price: 5.99,
  category: 'Lácteos',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1e309c446-1778083559133.png",
  description: 'Yogur griego natural espeso y cremoso con 20g de proteína por porción. Cultivos activos vivos. Sin espesantes ni sabores artificiales. Sin gluten.',
  stock: 29,
  sku: 'DAI-GYP-32',
  unit: 'envase'
},
{
  id: 'prod-009',
  name: 'Queso Cheddar Curado 16oz',
  price: 7.49,
  category: 'Lácteos',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_11caeefed-1779157265433.png",
  description: 'Queso cheddar curado con sabor intenso y ligeramente ácido. Pre-rebanado para mayor comodidad. Elaborado con leche libre de rBST. Ideal para sándwiches y snacks.',
  stock: 7,
  sku: 'DAI-SCC-16',
  unit: 'paquete'
},
{
  id: 'prod-010',
  name: 'Pan de Masa Madre 24oz',
  price: 5.49,
  category: 'Panadería',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_10dfcca0f-1772377421150.png",
  description: 'Pan artesanal de masa madre horneado fresco a diario con corteza crujiente e interior esponjoso. Elaborado con fermento de 48 horas. Sin conservantes.',
  stock: 15,
  sku: 'BAK-SDL-24',
  unit: 'hogaza'
},
{
  id: 'prod-011',
  name: 'Muffins de Arándano 4 unidades',
  price: 4.79,
  category: 'Panadería',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1e2e21c8f-1772780214630.png",
  description: 'Muffins húmedos y esponjosos cargados de arándanos frescos y cubiertos con crumble de streusel. Horneados frescos cada mañana.',
  stock: 11,
  sku: 'BAK-BLM-4PK',
  unit: 'paquete'
},
{
  id: 'prod-012',
  name: 'Croissants de Mantequilla 3 unidades',
  price: 4.29,
  category: 'Panadería',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1a0f08120-1772413576166.png",
  description: 'Croissants hojaldrados y mantecosos estilo francés elaborados con mantequilla 100% real y masa laminada. Exterior dorado con capas suaves y aireadas.',
  stock: 19,
  sku: 'BAK-CRB-3PK',
  unit: 'paquete'
},
{
  id: 'prod-013',
  name: 'Bananas Orgánicas 1 racimo',
  price: 1.49,
  category: 'Frutas y Verduras',
  image: "https://images.unsplash.com/photo-1632799149568-0b50371d44ab",
  description: 'Bananas orgánicas certificadas cultivadas sin pesticidas sintéticos. Naturalmente dulces y ricas en potasio. Se venden por racimo (aprox. 6–7 bananas).',
  stock: 95,
  sku: 'PRO-OBN-BCH',
  unit: 'racimo'
},
{
  id: 'prod-014',
  name: 'Espinaca Baby 5oz Bolsa',
  price: 3.49,
  category: 'Frutas y Verduras',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_10ff2c4b6-1779157265777.png",
  description: 'Hojas tiernas de espinaca baby prelavadas y listas para consumir. Ricas en hierro, vitaminas A y C. Lavadas tres veces para mayor comodidad.',
  stock: 38,
  sku: 'PRO-BSP-5OZ',
  unit: 'bolsa'
},
{
  id: 'prod-015',
  name: 'Pizza Margarita Congelada 12"',
  price: 8.99,
  category: 'Congelados',
  image: "https://images.unsplash.com/photo-1726298882906-6d01c9116e13",
  description: 'Pizza Margarita clásica con salsa de tomate San Marzano, mozzarella fresca y albahaca sobre una base crujiente y delgada. Lista en 12 minutos.',
  stock: 26,
  sku: 'FRZ-MPI-12',
  unit: 'pizza'
},
{
  id: 'prod-016',
  name: 'Shampoo Hidratante 12oz',
  price: 6.99,
  category: 'Cuidado Personal',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_125f0ccc4-1768492670571.png",
  description: 'Shampoo hidratante enriquecido con aceite de argán y keratina para un cabello suave y sin frizz. Fórmula sin sulfatos, segura para cabello teñido.',
  stock: 44,
  sku: 'PC-SHM-12',
  unit: 'botella'
},
{
  id: 'prod-017',
  name: 'Jabón Lavavajillas Limón 28oz',
  price: 3.99,
  category: 'Hogar',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_181bb64ba-1765097405377.png",
  description: 'Jabón lavavajillas concentrado con aroma a limón que elimina la grasa y los residuos horneados. Suave con las manos, eficaz contra la suciedad. Fórmula biodegradable.',
  stock: 5,
  sku: 'HH-DSL-28',
  unit: 'botella'
},
{
  id: 'prod-018',
  name: 'Toallas de Papel 6 rollos',
  price: 9.49,
  category: 'Hogar',
  image: "https://img.rocket.new/generatedImages/rocket_gen_img_1c49f948b-1765097404987.png",
  description: 'Toallas de papel de 2 capas súper absorbentes. Cada rollo tiene 90 hojas de tamaño seleccionable. Resistentes cuando están húmedas, suaves en superficies. Fabricadas con papel de fuentes sostenibles.',
  stock: 33,
  sku: 'HH-PTW-6RL',
  unit: 'paquete'
}];