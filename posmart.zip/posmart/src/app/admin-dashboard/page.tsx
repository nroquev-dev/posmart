import React from 'react';
import Navbar from '@/components/Navbar';
import CartDrawer from '@/components/CartDrawer';
import AdminDashboardContent from '@/app/admin-dashboard/components/AdminDashboardContent';

export default function AdminDashboardPage() {
  return (
    <>
      <Navbar />
      <CartDrawer />
      <AdminDashboardContent />
    </>
  );
}