import React from 'react';
import {
  DollarSign,
  ShoppingBag,
  TrendingUp,
  Star,
  Package,
  AlertTriangle,
} from 'lucide-react';
import Icon from '@/components/ui/AppIcon';


const KPIS = [
  {
    id: 'kpi-total-sales',
    label: 'Ventas Totales Hoy',
    value: '$2,847.63',
    sub: '+$312 vs ayer',
    trend: 'up',
    icon: DollarSign,
    color: 'text-positive',
    bg: 'bg-green-50',
    border: 'border-green-100',
    featured: true,
  },
  {
    id: 'kpi-orders-today',
    label: 'Pedidos Hoy',
    value: '47',
    sub: '+8 vs ayer',
    trend: 'up',
    icon: ShoppingBag,
    color: 'text-blue-600',
    bg: 'bg-blue-50',
    border: 'border-blue-100',
    featured: false,
  },
  {
    id: 'kpi-avg-order',
    label: 'Valor Promedio de Pedido',
    value: '$60.59',
    sub: '-$4.20 vs ayer',
    trend: 'down',
    icon: TrendingUp,
    color: 'text-orange-600',
    bg: 'bg-orange-50',
    border: 'border-orange-100',
    featured: false,
  },
  {
    id: 'kpi-top-category',
    label: 'Categoría Principal',
    value: 'Bebidas',
    sub: '31% de las ventas de hoy',
    trend: 'neutral',
    icon: Star,
    color: 'text-primary',
    bg: 'bg-teal-50',
    border: 'border-teal-100',
    featured: false,
  },
  {
    id: 'kpi-active-products',
    label: 'Productos Activos',
    value: '18',
    sub: '3 artículos con poco stock',
    trend: 'neutral',
    icon: Package,
    color: 'text-muted-foreground',
    bg: 'bg-muted',
    border: 'border-border',
    featured: false,
  },
  {
    id: 'kpi-low-stock',
    label: 'Alertas de Poco Stock',
    value: '3',
    sub: 'Necesita reorden hoy',
    trend: 'alert',
    icon: AlertTriangle,
    color: 'text-warning',
    bg: 'bg-amber-50',
    border: 'border-amber-200',
    featured: false,
  },
];

export default function KPIGrid() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-6 gap-4">
      {KPIS?.map((kpi) => {
        const Icon = kpi?.icon;
        return (
          <div
            key={kpi?.id}
            className={`relative p-5 bg-card rounded-xl border ${kpi?.border} shadow-card flex flex-col gap-3 card-hover ${
              kpi?.featured ? '2xl:col-span-2' : ''
            } ${kpi?.trend === 'alert' ? 'ring-1 ring-amber-300' : ''}`}
          >
            <div className="flex items-start justify-between">
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                {kpi?.label}
              </p>
              <div className={`w-8 h-8 rounded-lg ${kpi?.bg} flex items-center justify-center shrink-0`}>
                <Icon size={16} className={kpi?.color} />
              </div>
            </div>
            <div>
              <p className={`text-2xl font-bold tabular-nums ${kpi?.featured ? 'text-3xl' : ''} ${
                kpi?.trend === 'alert' ? 'text-warning' : 'text-foreground'
              }`}>
                {kpi?.value}
              </p>
              <p className={`text-xs mt-1 font-medium ${
                kpi?.trend === 'up' ? 'text-positive'
                  : kpi?.trend === 'down' ? 'text-negative'
                  : kpi?.trend === 'alert' ? 'text-warning' : 'text-muted-foreground'
              }`}>
                {kpi?.trend === 'up' && '↑ '}
                {kpi?.trend === 'down' && '↓ '}
                {kpi?.sub}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}