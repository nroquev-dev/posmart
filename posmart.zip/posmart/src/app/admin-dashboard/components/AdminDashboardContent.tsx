import React from 'react';
import KPIGrid from './KPIGrid';
import SalesTrendChart from './SalesTrendChart';
import CategorySalesChart from './CategorySalesChart';
import RecentTransactionsTable from './RecentTransactionsTable';
import LowStockAlerts from './LowStockAlerts';

export default function AdminDashboardContent() {
  return (
    <main className="max-w-screen-2xl mx-auto px-4 lg:px-8 xl:px-10 2xl:px-16 py-6">
      {/* Page header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Panel de Administración</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Lunes, 18 de mayo de 2026 — Resumen de rendimiento de la tienda
          </p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 border border-green-200 rounded-lg">
          <div className="w-2 h-2 rounded-full bg-positive animate-pulse" />
          <span className="text-xs font-medium text-positive">En Vivo</span>
        </div>
      </div>

      {/* KPI Bento Grid */}
      <KPIGrid />

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-3 gap-5 mt-5">
        <div className="lg:col-span-2">
          <SalesTrendChart />
        </div>
        <div>
          <CategorySalesChart />
        </div>
      </div>

      {/* Bottom row: transactions + low stock */}
      <div className="grid grid-cols-1 xl:grid-cols-3 2xl:grid-cols-3 gap-5 mt-5">
        <div className="xl:col-span-2">
          <RecentTransactionsTable />
        </div>
        <div>
          <LowStockAlerts />
        </div>
      </div>
    </main>
  );
}