'use client';
import React from 'react';
import dynamic from 'next/dynamic';

const CategorySalesChartInner = dynamic(() => import('./CategorySalesChartInner'), { ssr: false });

export default function CategorySalesChart() {
  return <CategorySalesChartInner />;
}