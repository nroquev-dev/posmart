'use client';
import React, { useState } from 'react';
import { Search, ChevronUp, ChevronDown, Eye, ReceiptText } from 'lucide-react';

type Transaction = {
  id: string;
  orderId: string;
  cashier: string;
  items: number;
  subtotal: number;
  tax: number;
  total: number;
  time: string;
  status: 'Completado' | 'Anulado' | 'Reembolsado';
};

const TRANSACTIONS: Transaction[] = [
  { id: 'txn-001', orderId: '#PED-4721', cashier: 'María González', items: 6, subtotal: 34.22, tax: 2.99, total: 37.21, time: '9:04 AM', status: 'Completado' },
  { id: 'txn-002', orderId: '#PED-4722', cashier: 'James Okafor', items: 2, subtotal: 11.48, tax: 1.00, total: 12.48, time: '9:18 AM', status: 'Completado' },
  { id: 'txn-003', orderId: '#PED-4723', cashier: 'María González', items: 9, subtotal: 72.14, tax: 6.31, total: 78.45, time: '9:33 AM', status: 'Completado' },
  { id: 'txn-004', orderId: '#PED-4724', cashier: 'Luis Mendoza', items: 1, subtotal: 4.49, tax: 0.39, total: 4.88, time: '9:51 AM', status: 'Anulado' },
  { id: 'txn-005', orderId: '#PED-4725', cashier: 'Sarah Kim', items: 14, subtotal: 118.73, tax: 10.39, total: 129.12, time: '10:07 AM', status: 'Completado' },
  { id: 'txn-006', orderId: '#PED-4726', cashier: 'James Okafor', items: 4, subtotal: 27.16, tax: 2.38, total: 29.54, time: '10:22 AM', status: 'Completado' },
  { id: 'txn-007', orderId: '#PED-4727', cashier: 'María González', items: 3, subtotal: 16.27, tax: 1.42, total: 17.69, time: '10:44 AM', status: 'Reembolsado' },
  { id: 'txn-008', orderId: '#PED-4728', cashier: 'Luis Mendoza', items: 7, subtotal: 53.91, tax: 4.72, total: 58.63, time: '11:02 AM', status: 'Completado' },
  { id: 'txn-009', orderId: '#PED-4729', cashier: 'Sarah Kim', items: 5, subtotal: 42.55, tax: 3.72, total: 46.27, time: '11:19 AM', status: 'Completado' },
  { id: 'txn-010', orderId: '#PED-4730', cashier: 'James Okafor', items: 11, subtotal: 89.40, tax: 7.82, total: 97.22, time: '11:38 AM', status: 'Completado' },
];

const STATUS_STYLES: Record<Transaction['status'], string> = {
  Completado: 'bg-green-50 text-positive border-green-200',
  Anulado: 'bg-red-50 text-negative border-red-200',
  Reembolsado: 'bg-amber-50 text-warning border-amber-200',
};

type SortKey = 'time' | 'total' | 'items' | 'cashier';

export default function RecentTransactionsTable() {
  const [search, setSearch] = useState('');
  const [sortKey, setSortKey] = useState<SortKey>('time');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  const handleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  };

  const filtered = TRANSACTIONS
    .filter((t) =>
      t.orderId.toLowerCase().includes(search.toLowerCase()) ||
      t.cashier.toLowerCase().includes(search.toLowerCase())
    )
    .sort((a, b) => {
      const dir = sortDir === 'asc' ? 1 : -1;
      if (sortKey === 'total') return (a.total - b.total) * dir;
      if (sortKey === 'items') return (a.items - b.items) * dir;
      if (sortKey === 'cashier') return a.cashier.localeCompare(b.cashier) * dir;
      return a.time.localeCompare(b.time) * dir;
    });

  const SortIcon = ({ col }: { col: SortKey }) => (
    <span className="inline-flex flex-col ml-1 opacity-50">
      <ChevronUp size={10} className={sortKey === col && sortDir === 'asc' ? 'opacity-100 text-primary' : ''} />
      <ChevronDown size={10} className={sortKey === col && sortDir === 'desc' ? 'opacity-100 text-primary' : ''} style={{ marginTop: '-3px' }} />
    </span>
  );

  return (
    <div className="bg-card rounded-xl border border-border shadow-card">
      <div className="flex items-center justify-between px-5 py-4 border-b border-border gap-3">
        <div>
          <h3 className="font-semibold text-foreground">Transacciones Recientes</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Hoy — {filtered.length} pedidos</p>
        </div>
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
          <input
            type="text"
            placeholder="Buscar pedido o cajero…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 pr-3 py-2 text-sm bg-background border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring w-52"
          />
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/50">
              <th className="text-left px-5 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide whitespace-nowrap">
                N° Pedido
              </th>
              <th
                className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide whitespace-nowrap cursor-pointer hover:text-foreground select-none"
                onClick={() => handleSort('cashier')}
              >
                Cajero <SortIcon col="cashier" />
              </th>
              <th
                className="text-right px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide whitespace-nowrap cursor-pointer hover:text-foreground select-none"
                onClick={() => handleSort('items')}
              >
                Artículos <SortIcon col="items" />
              </th>
              <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide whitespace-nowrap">
                Subtotal
              </th>
              <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide whitespace-nowrap">
                Impuesto
              </th>
              <th
                className="text-right px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide whitespace-nowrap cursor-pointer hover:text-foreground select-none"
                onClick={() => handleSort('total')}
              >
                Total <SortIcon col="total" />
              </th>
              <th
                className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide whitespace-nowrap cursor-pointer hover:text-foreground select-none"
                onClick={() => handleSort('time')}
              >
                Hora <SortIcon col="time" />
              </th>
              <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase tracking-wide whitespace-nowrap">
                Estado
              </th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={9} className="text-center py-12 text-muted-foreground text-sm">
                  <ReceiptText size={24} className="mx-auto mb-2 opacity-40" />
                  No hay transacciones que coincidan con tu búsqueda
                </td>
              </tr>
            ) : (
              filtered.map((txn, idx) => (
                <tr
                  key={txn.id}
                  className={`border-b border-border last:border-0 hover:bg-muted/40 transition-colors ${
                    idx % 2 === 0 ? '' : 'bg-muted/20'
                  }`}
                >
                  <td className="px-5 py-3 font-mono text-xs font-medium text-foreground whitespace-nowrap">
                    {txn.orderId}
                  </td>
                  <td className="px-4 py-3 text-foreground whitespace-nowrap">{txn.cashier}</td>
                  <td className="px-4 py-3 text-right tabular-nums text-muted-foreground">{txn.items}</td>
                  <td className="px-4 py-3 text-right tabular-nums text-foreground">${txn.subtotal.toFixed(2)}</td>
                  <td className="px-4 py-3 text-right tabular-nums text-muted-foreground">${txn.tax.toFixed(2)}</td>
                  <td className="px-4 py-3 text-right tabular-nums font-semibold text-foreground">${txn.total.toFixed(2)}</td>
                  <td className="px-4 py-3 text-muted-foreground whitespace-nowrap text-xs">{txn.time}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex px-2.5 py-1 text-xs font-semibold rounded-full border ${STATUS_STYLES[txn.status]}`}>
                      {txn.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <button
                      className="p-1.5 rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground transition-colors opacity-0 group-hover:opacity-100"
                      aria-label={`Ver detalles de ${txn.orderId}`}
                    >
                      <Eye size={14} />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="px-5 py-3 border-t border-border flex items-center justify-between text-xs text-muted-foreground">
        <span>{filtered.length} de {TRANSACTIONS.length} transacciones mostradas</span>
        <span className="font-semibold text-foreground tabular-nums">
          Total del día: ${TRANSACTIONS.filter(t => t.status === 'Completado').reduce((s, t) => s + t.total, 0).toFixed(2)}
        </span>
      </div>
    </div>
  );
}