'use client';
import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';

const CATEGORY_DATA = [
  { category: 'Bebidas', revenue: 881, color: '#3b82f6' },
  { category: 'Snacks', revenue: 512, color: '#f97316' },
  { category: 'Lácteos', revenue: 428, color: '#eab308' },
  { category: 'Panadería', revenue: 390, color: '#f59e0b' },
  { category: 'Frutas/Verd.', revenue: 284, color: '#22c55e' },
  { category: 'Congelados', revenue: 199, color: '#06b6d4' },
  { category: 'Hogar', revenue: 153, color: '#64748b' },
];

type TooltipProps = {
  active?: boolean;
  payload?: Array<{ value: number }>;
  label?: string;
};

function CustomTooltip({ active, payload, label }: TooltipProps) {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div className="bg-card border border-border rounded-xl shadow-card-md px-4 py-3 text-sm">
      <p className="font-semibold text-foreground">{label}</p>
      <p className="text-primary font-bold tabular-nums mt-1">${payload[0]?.value.toLocaleString()}</p>
    </div>
  );
}

export default function CategorySalesChartInner() {
  return (
    <div className="bg-card rounded-xl border border-border shadow-card p-5 h-full">
      <div className="mb-5">
        <h3 className="font-semibold text-foreground">Ventas por Categoría</h3>
        <p className="text-xs text-muted-foreground mt-0.5">Desglose de ingresos de hoy</p>
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={CATEGORY_DATA} margin={{ top: 4, right: 4, bottom: 0, left: 0 }} barSize={18}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" horizontal vertical={false} />
          <XAxis
            dataKey="category"
            tick={{ fontSize: 10, fill: 'var(--muted-foreground)' }}
            axisLine={false}
            tickLine={false}
            angle={-35}
            textAnchor="end"
            height={48}
          />
          <YAxis
            tick={{ fontSize: 11, fill: 'var(--muted-foreground)' }}
            axisLine={false}
            tickLine={false}
            tickFormatter={(v) => `$${v}`}
            width={44}
          />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: 'var(--muted)', opacity: 0.5 }} />
          <Bar dataKey="revenue" radius={[4, 4, 0, 0]}>
            {CATEGORY_DATA.map((entry) => (
              <Cell key={`cat-bar-${entry.category}`} fill={entry.color} fillOpacity={0.85} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}