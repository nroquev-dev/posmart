import React from 'react';
import { AlertTriangle, Package, ArrowRight } from 'lucide-react';
import { PRODUCTS } from '@/data/products';

const LOW_STOCK_THRESHOLD = 15;

export default function LowStockAlerts() {
  const lowStockItems = PRODUCTS?.filter((p) => p?.stock <= LOW_STOCK_THRESHOLD)?.sort((a, b) => a?.stock - b?.stock);

  return (
    <div className="bg-card rounded-xl border border-amber-200 shadow-card h-full">
      <div className="flex items-center gap-2 px-5 py-4 border-b border-amber-100 bg-amber-50 rounded-t-xl">
        <AlertTriangle size={16} className="text-warning shrink-0" />
        <div className="flex-1">
          <h3 className="font-semibold text-foreground text-sm">Alertas de Poco Stock</h3>
          <p className="text-xs text-muted-foreground">
            {lowStockItems?.length} productos necesitan reorden
          </p>
        </div>
        <span className="px-2 py-1 bg-warning/20 text-warning text-xs font-bold rounded-full tabular-nums">
          {lowStockItems?.length}
        </span>
      </div>
      <div className="divide-y divide-border">
        {lowStockItems?.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-10 px-4 text-center">
            <Package size={24} className="text-muted-foreground opacity-40" />
            <p className="text-sm text-muted-foreground">Todos los productos tienen buen stock</p>
          </div>
        ) : (
          lowStockItems?.map((product) => {
            const isVeryLow = product?.stock <= 7;
            return (
              <div
                key={`low-stock-${product?.id}`}
                className="flex items-center gap-3 px-4 py-3 hover:bg-muted/40 transition-colors"
              >
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                    isVeryLow ? 'bg-red-50' : 'bg-amber-50'
                  }`}
                >
                  <Package size={14} className={isVeryLow ? 'text-negative' : 'text-warning'} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground line-clamp-1">{product?.name}</p>
                  <p className="text-xs text-muted-foreground">{product?.sku}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className={`text-sm font-bold tabular-nums ${isVeryLow ? 'text-negative' : 'text-warning'}`}>
                    {product?.stock}
                  </p>
                  <p className="text-xs text-muted-foreground">{product?.unit}(s) restantes</p>
                </div>
              </div>
            );
          })
        )}
      </div>
      {lowStockItems?.length > 0 && (
        <div className="px-4 py-3 border-t border-border">
          <button className="w-full flex items-center justify-center gap-2 py-2 text-xs font-medium text-primary hover:bg-primary/5 rounded-lg transition-colors">
            Ver todo el inventario
            <ArrowRight size={12} />
          </button>
        </div>
      )}
    </div>
  );
}