'use client';
import React from 'react';
import dynamic from 'next/dynamic';

const SalesTrendChartInner = dynamic(() => import('./SalesTrendChartInner'), { ssr: false });

export default function SalesTrendChart() {
  return <SalesTrendChartInner />;
}