'use client';
import React, { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, X, Package } from 'lucide-react';
import { PRODUCTS, CATEGORIES } from '@/data/products';
import ProductCard from '@/components/ProductCard';
import CategoryFilter from '@/components/CategoryFilter';

export default function ProductCatalogContent() {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [sortBy, setSortBy] = useState<'name' | 'price-asc' | 'price-desc'>('name');

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = { Todos: PRODUCTS.length };
    CATEGORIES.forEach((cat) => {
      if (cat !== 'Todos') {
        counts[cat] = PRODUCTS.filter((p) => p.category === cat).length;
      }
    });
    return counts;
  }, []);

  const filtered = useMemo(() => {
    let list = [...PRODUCTS];
    if (selectedCategory !== 'Todos') {
      list = list.filter((p) => p.category === selectedCategory);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.sku.toLowerCase().includes(q)
      );
    }
    if (sortBy === 'name') list.sort((a, b) => a.name.localeCompare(b.name));
    if (sortBy === 'price-asc') list.sort((a, b) => a.price - b.price);
    if (sortBy === 'price-desc') list.sort((a, b) => b.price - a.price);
    return list;
  }, [search, selectedCategory, sortBy]);

  return (
    <main className="max-w-screen-2xl mx-auto px-4 lg:px-8 xl:px-10 2xl:px-16 py-6">
      {/* Encabezado de página */}
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-foreground">Catálogo de Productos</h1>
        <p className="text-sm text-muted-foreground mt-1">
          {PRODUCTS.length} productos en {CATEGORIES.length - 1} categorías
        </p>
      </div>

      {/* Búsqueda + Ordenar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search
            size={16}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"
          />
          <input
            type="text"
            placeholder="Buscar productos por nombre, categoría o SKU…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-9 py-2.5 text-sm bg-card border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent transition-all"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label="Limpiar búsqueda"
            >
              <X size={14} />
            </button>
          )}
        </div>
        <div className="flex items-center gap-2">
          <SlidersHorizontal size={16} className="text-muted-foreground shrink-0" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
            className="text-sm bg-card border border-border rounded-xl px-3 py-2.5 text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-all appearance-none cursor-pointer pr-8"
          >
            <option value="name">Ordenar: Nombre A–Z</option>
            <option value="price-asc">Ordenar: Precio Menor–Mayor</option>
            <option value="price-desc">Ordenar: Precio Mayor–Menor</option>
          </select>
        </div>
      </div>

      {/* Filtro de categorías */}
      <div className="mb-6">
        <CategoryFilter
          selected={selectedCategory}
          onChange={setSelectedCategory}
          counts={categoryCounts}
        />
      </div>

      {/* Contador de resultados */}
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-muted-foreground">
          Mostrando <span className="font-semibold text-foreground">{filtered.length}</span> productos
          {selectedCategory !== 'Todos' && (
            <span>
              {' '}en <span className="text-primary font-medium">{selectedCategory}</span>
            </span>
          )}
          {search && (
            <span>
              {' '}para <span className="text-primary font-medium">"{search}"</span>
            </span>
          )}
        </p>
        {(search || selectedCategory !== 'Todos') && (
          <button
            onClick={() => { setSearch(''); setSelectedCategory('Todos'); }}
            className="text-xs text-primary hover:underline font-medium"
          >
            Limpiar filtros
          </button>
        )}
      </div>

      {/* Cuadrícula */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 gap-4">
          <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center">
            <Package size={28} className="text-muted-foreground" />
          </div>
          <div className="text-center">
            <p className="font-semibold text-foreground text-lg">No se encontraron productos</p>
            <p className="text-sm text-muted-foreground mt-1 max-w-xs">
              Intenta ajustar tu búsqueda o limpiar el filtro de categoría para encontrar lo que necesitas.
            </p>
          </div>
          <button
            onClick={() => { setSearch(''); setSelectedCategory('Todos'); }}
            className="px-4 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors"
          >
            Ver Todos los Productos
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4">
          {filtered.map((product) => (
            <ProductCard key={`catalog-${product.id}`} product={product} />
          ))}
        </div>
      )}
    </main>
  );
}