import React from 'react';
import Navbar from '@/components/Navbar';
import CartDrawer from '@/components/CartDrawer';
import ProductCatalogContent from '@/app/components/ProductCatalogContent';

export default function ProductCatalogPage() {
  return (
    <>
      <Navbar />
      <CartDrawer />
      <ProductCatalogContent />
    </>
  );
}