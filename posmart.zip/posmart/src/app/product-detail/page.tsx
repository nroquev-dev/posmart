import React, { Suspense } from 'react';
import Navbar from '@/components/Navbar';
import CartDrawer from '@/components/CartDrawer';
import ProductDetailContent from '@/app/product-detail/components/ProductDetailContent';

export default function ProductDetailPage() {
  return (
    <>
      <Navbar />
      <CartDrawer />
      <Suspense fallback={<div className="flex items-center justify-center min-h-screen"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div></div>}>
        <ProductDetailContent />
      </Suspense>
    </>
  );
}