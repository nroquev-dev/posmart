'use client';
import React, { useState, useMemo } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import {
  ChevronLeft,
  ShoppingCart,
  Plus,
  Minus,
  Package,
  AlertTriangle,
  CheckCircle2,
  Tag,
  Hash,
  Layers,
} from 'lucide-react';
import AppImage from '@/components/ui/AppImage';
import ProductCard from '@/components/ProductCard';
import { PRODUCTS } from '@/data/products';
import { useCartStore } from '@/store/cartStore';
import { toast } from 'sonner';

const CATEGORY_COLORS: Record<string, string> = {
  Bebidas: 'bg-blue-50 text-blue-700 border-blue-200',
  Snacks: 'bg-orange-50 text-orange-700 border-orange-200',
  Lácteos: 'bg-yellow-50 text-yellow-700 border-yellow-200',
  Panadería: 'bg-amber-50 text-amber-700 border-amber-200',
  'Frutas y Verduras': 'bg-green-50 text-green-700 border-green-200',
  Congelados: 'bg-cyan-50 text-cyan-700 border-cyan-200',
  'Cuidado Personal': 'bg-purple-50 text-purple-700 border-purple-200',
  Hogar: 'bg-slate-100 text-slate-700 border-slate-200',
};

export default function ProductDetailContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const id = searchParams.get('id');
  const [qty, setQty] = useState(1);
  const [adding, setAdding] = useState(false);

  const { addItem, openCart } = useCartStore();

  const product = useMemo(() => PRODUCTS.find((p) => p.id === id), [id]);

  const related = useMemo(() => {
    if (!product) return [];
    return PRODUCTS.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);
  }, [product]);

  if (!product) {
    return (
      <main className="max-w-screen-2xl mx-auto px-4 lg:px-8 xl:px-10 py-16 flex flex-col items-center gap-4">
        <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center">
          <Package size={28} className="text-muted-foreground" />
        </div>
        <p className="font-semibold text-foreground text-lg">Producto no encontrado</p>
        <p className="text-sm text-muted-foreground">
          El producto que buscas no existe o ha sido eliminado.
        </p>
        <button
          onClick={() => router.push('/')}
          className="px-4 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-lg hover:bg-primary/90 transition-colors"
        >
          Volver al Catálogo
        </button>
      </main>
    );
  }

  const isLowStock = product.stock <= 10;
  const isOutOfStock = product.stock === 0;
  const badgeColor = CATEGORY_COLORS[product.category] ?? 'bg-muted text-muted-foreground border-border';

  const handleAddToCart = () => {
    if (isOutOfStock) return;
    setAdding(true);
    for (let i = 0; i < qty; i++) addItem(product);
    toast.success(`${qty}× ${product.name} agregado al carrito`, {
      action: { label: 'Ver Carrito', onClick: openCart },
    });
    setTimeout(() => setAdding(false), 400);
  };

  return (
    <main className="max-w-screen-2xl mx-auto px-4 lg:px-8 xl:px-10 2xl:px-16 py-6">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 mb-6 text-sm">
        <button
          onClick={() => router.push('/')}
          className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors font-medium"
        >
          <ChevronLeft size={16} />
          Catálogo de Productos
        </button>
        <span className="text-border">/</span>
        <span className="text-muted-foreground">{product.category}</span>
        <span className="text-border">/</span>
        <span className="text-foreground font-medium line-clamp-1">{product.name}</span>
      </nav>

      {/* Main detail */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 xl:gap-12 mb-12">
        {/* Image */}
        <div className="space-y-3">
          <div className="aspect-square rounded-2xl overflow-hidden bg-muted border border-border relative">
            <AppImage
              src={product.image}
              alt={`${product.name} — imagen detallada de producto ${product.category}`}
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              priority
              className="object-cover"
            />
            {isLowStock && !isOutOfStock && (
              <div className="absolute top-4 left-4 flex items-center gap-1.5 px-3 py-1.5 bg-warning/95 text-white text-sm font-semibold rounded-full">
                <AlertTriangle size={14} />
                Poco Stock — quedan {product.stock}
              </div>
            )}
          </div>
        </div>

        {/* Info */}
        <div className="flex flex-col gap-5">
          {/* Category + SKU */}
          <div className="flex items-center gap-3 flex-wrap">
            <span className={`text-xs font-semibold px-3 py-1 rounded-full border ${badgeColor}`}>
              {product.category}
            </span>
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Hash size={11} />
              {product.sku}
            </span>
          </div>

          {/* Name */}
          <h1 className="text-2xl font-semibold text-foreground leading-snug">
            {product.name}
          </h1>

          {/* Price */}
          <div className="flex items-baseline gap-3">
            <span className="text-4xl font-bold text-foreground tabular-nums">
              ${product.price.toFixed(2)}
            </span>
            <span className="text-sm text-muted-foreground">por {product.unit}</span>
          </div>

          {/* Stock status */}
          <div className="flex items-center gap-2">
            {isOutOfStock ? (
              <div className="flex items-center gap-2 px-3 py-2 bg-red-50 border border-red-200 rounded-lg">
                <div className="w-2 h-2 rounded-full bg-negative" />
                <span className="text-sm font-medium text-negative">Sin Stock</span>
              </div>
            ) : isLowStock ? (
              <div className="flex items-center gap-2 px-3 py-2 bg-amber-50 border border-amber-200 rounded-lg">
                <AlertTriangle size={14} className="text-warning" />
                <span className="text-sm font-medium text-warning">
                  Poco Stock — solo quedan {product.stock} {product.unit}(s)
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-2 px-3 py-2 bg-green-50 border border-green-200 rounded-lg">
                <CheckCircle2 size={14} className="text-positive" />
                <span className="text-sm font-medium text-positive">
                  En Stock — {product.stock} {product.unit}(s) disponibles
                </span>
              </div>
            )}
          </div>

          {/* Description */}
          <div className="space-y-2">
            <h2 className="text-sm font-semibold text-foreground uppercase tracking-wide">
              Descripción
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {product.description}
            </p>
          </div>

          {/* Meta */}
          <div className="grid grid-cols-2 gap-3 p-4 bg-muted rounded-xl">
            <div className="flex items-center gap-2">
              <Tag size={14} className="text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Categoría</p>
                <p className="text-sm font-medium text-foreground">{product.category}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Layers size={14} className="text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Tipo de Unidad</p>
                <p className="text-sm font-medium text-foreground capitalize">{product.unit}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Hash size={14} className="text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">SKU</p>
                <p className="text-sm font-mono font-medium text-foreground">{product.sku}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Package size={14} className="text-muted-foreground" />
              <div>
                <p className="text-xs text-muted-foreground">Stock</p>
                <p className={`text-sm font-medium ${isLowStock ? 'text-warning' : 'text-foreground'}`}>
                  {product.stock} {product.unit}(s)
                </p>
              </div>
            </div>
          </div>

          {/* Quantity + Add to cart */}
          <div className="flex items-center gap-3">
            {/* Qty stepper */}
            <div className="flex items-center border border-border rounded-xl overflow-hidden bg-card">
              <button
                onClick={() => setQty(Math.max(1, qty - 1))}
                disabled={qty <= 1}
                className="w-10 h-11 flex items-center justify-center text-muted-foreground hover:bg-muted hover:text-foreground transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                aria-label="Disminuir cantidad"
              >
                <Minus size={14} />
              </button>
              <span className="w-12 text-center text-sm font-semibold tabular-nums text-foreground">
                {qty}
              </span>
              <button
                onClick={() => setQty(Math.min(product.stock, qty + 1))}
                disabled={qty >= product.stock || isOutOfStock}
                className="w-10 h-11 flex items-center justify-center text-muted-foreground hover:bg-muted hover:text-foreground transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                aria-label="Aumentar cantidad"
              >
                <Plus size={14} />
              </button>
            </div>

            {/* Add to cart button */}
            <button
              onClick={handleAddToCart}
              disabled={isOutOfStock}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-semibold transition-all duration-150 active:scale-95 ${
                isOutOfStock
                  ? 'bg-muted text-muted-foreground cursor-not-allowed'
                  : adding
                  ? 'bg-positive text-white' :'bg-primary text-primary-foreground hover:bg-primary/90'
              }`}
            >
              <ShoppingCart size={16} />
              {adding
                ? `¡${qty}× Agregado al Carrito!`
                : `Agregar ${qty > 1 ? `${qty}×` : ''} al Carrito — $${(product.price * qty).toFixed(2)}`}
            </button>
          </div>
        </div>
      </div>

      {/* Related products */}
      {related.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-foreground">
              Más en {product.category}
            </h2>
            <button
              onClick={() => router.push(`/?category=${product.category}`)}
              className="text-sm text-primary hover:underline font-medium"
            >
              Ver todos
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {related.map((p) => (
              <ProductCard key={`related-${p.id}`} product={p} />
            ))}
          </div>
        </section>
      )}

      {/* Mobile sticky bottom bar */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-card border-t border-border px-4 py-3 flex items-center gap-3">
        <div className="flex-1">
          <p className="text-xs text-muted-foreground">{product.name}</p>
          <p className="text-lg font-bold text-foreground tabular-nums">
            ${(product.price * qty).toFixed(2)}
          </p>
        </div>
        <button
          onClick={handleAddToCart}
          disabled={isOutOfStock}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all active:scale-95 ${
            isOutOfStock
              ? 'bg-muted text-muted-foreground cursor-not-allowed'
              : 'bg-primary text-primary-foreground hover:bg-primary/90'
          }`}
        >
          <ShoppingCart size={15} />
          Agregar al Carrito
        </button>
      </div>
    </main>
  );
}